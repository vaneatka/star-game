class Space extends Entity{
            constructor(x, y, w, h, speed) {
            super(x, y, w, h, speed);
            this.entities = []; // shuttles, mines, stations
            this.id = 'space';
            }
    addEntity(entity){
        this.entities.push(entity);
    }
    render(){
        // render elementelor din spatiu
        let content = ``;
        this.entities.forEach(element => {
            content += element.render();
        });
        let html = super.render(content);
        return html;
    }
}